# DICOM 모듈

DICOM 파일 관련 비즈니스 로직을 제공하는 Core Module입니다.

---

## 목차

- [주요 기능](#주요-기능)
- [사용 방법](#사용-방법)
- [패키지 구조](#패키지-구조)
- [의존성](#의존성)
- [테스트](#테스트)
- [변경 이력](#변경-이력)

---

## 주요 기능

| 기능                   | 설명                                      |
|----------------------|-----------------------------------------|
| Multi-Frame DICOM 분리 | 멀티 프레임 DICOM 파일을 개별 싱글 프레임 DICOM 파일로 분리 |
| 픽셀 데이터 추출            | 8bit/16bit 픽셀 데이터 추출 및 바이트 배열 변환        |
| DICOM Tag 처리         | DICOM 표준/프라이빗 태그 읽기 및 수정                |
| DICOM 파일 저장          | 수정된 메타데이터로 새 DICOM 파일 생성                |

---

## 사용 방법

### Multi-Frame DICOM 파일 분리

`DicomFrameSplitterService`를 사용하여 멀티 프레임 DICOM 파일을 싱글 프레임으로 분리할 수 있습니다:

```java
private final DicomFrameSplitterService dicomFrameSplitterService;

// 멀티 프레임 DICOM 파일을 싱글 프레임으로 분리
File inputFile = new File("/path/to/multi-frame.dcm");
String outputPath = "/path/to/output/directory";

dicomFrameSplitterService.

process(inputFile, outputPath);
// 결과: outputPath에 multi-frame_0001.dcm, multi-frame_0002.dcm, ... 파일 생성
```

- 상세 내용은 [DICOM FRAME SPLITTER GUIDE](../../../docs/DICOM_FRAME_SPLITTER_GUIDE.md) 참고

### DICOM 유틸리티

`DicomUtil`을 통해 DICOM 태그 정보를 읽을 수 있습니다:

```java
// DICOM 파일에서 메타데이터 추출
DicomMetaData metaData = DicomUtil.getAttributes(dicomFile);

// DicomInputStream을 통한 태그 읽기
try (DicomInputStream dis = new DicomInputStream(dicomFile)) {
    // String 타입 태그 읽기
    String patientName = DicomUtil.readDicomTagToStr(dis, Tag.PatientName);

    // int 타입 태그 읽기
    int rows = DicomUtil.readDicomTagToInt(dis, Tag.Rows, 0);

    // Private 태그 읽기
    String privateValue = DicomUtil.readPrivateTagValue(dis, 0x0019, 0x1010);
}
```

---

## 패키지 구조

```
src/main/java/com/neurophet/maga/dicom/
├── DicomFrameSplitterService.java      # 메인 서비스 (Public API)
├── package-info.java                   # Spring Modulith 모듈 설정
└── internal/                           # 내부 구현 (캡슐화)
    ├── DicomPixelService.java          # 픽셀 데이터 추출 서비스
    ├── DicomStorageService.java        # DICOM 파일 저장 서비스
    ├── dto/
    │   ├── DicomMetaData.java          # DICOM 태그 정보 DTO
    │   └── DicomPixelData.java         # 픽셀 데이터 DTO
    ├── interfaces/
    │   ├── DicomPixelProvider.java     # 픽셀 처리 인터페이스
    │   └── DicomStorageProvider.java   # 저장 처리 인터페이스
    ├── support/
    │   └── DisposableDicomImageReader.java  # AutoCloseable ImageReader 래퍼
    └── utils/
        └── DicomUtil.java              # DICOM 유틸리티 클래스
```

### 모듈 경계

Spring Modulith를 사용하여 모듈 경계를 정의합니다. `internal` 패키지의 클래스들은 모듈 외부에서 직접 접근할 수 없습니다.

**허용된 의존성**:

- `common` 모듈
- `common::exceptions`
- `common::responses`
- `common::interfaces`
- `common::utils`

---

## 의존성

### 외부 라이브러리

| 라이브러리           | 설명                      |
|-----------------|-------------------------|
| dcm4che-core    | DICOM 표준 데이터 구조 및 태그 처리 |
| dcm4che-imageio | DICOM 이미지 I/O 처리        |

### 내부 모듈

| 모듈     | 설명               |
|--------|------------------|
| common | 공통 예외 처리, 유틸리티 등 |

---

## 테스트

```bash
# DICOM 모듈 테스트 실행
./gradlew :modules:core-modules:dicom:test
```

### 커버리지 리포트

테스트 커버리지 리포트는 다음 위치에서 확인할 수 있습니다:

- HTML: `build/reports/jacoco/test/html/index.html`
- XML: `build/reports/jacoco/test/jacocoTestReport.xml`

---

## 변경 이력

| 버전  | 날짜         | 변경 내역     | 작성자 |
|-----|------------|-----------|-----|
| 1.0 | 2025-12-31 | 초안 작성     | 서강희 |
| 1.1 | 2026-01-02 | 테스트 코드 보강 | 서강희 |
