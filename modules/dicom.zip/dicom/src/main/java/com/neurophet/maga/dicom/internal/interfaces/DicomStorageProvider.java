package com.neurophet.maga.dicom.internal.interfaces;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.dicom.internal.dto.DicomMetaData;

/**
 * DICOM 파일 저장
 *
 * @author 서강희
 */
public interface DicomStorageProvider {
    /**
     * DICOM 파일 저장 수행
     *
     * @param outputPath 저장될 위치
     * @param fileName   저장할 파일 이름
     * @param metaData   DICOM 파일 정보
     * @throws CommonException 파일 저장에 실패했을 경우 ( FILE_SYSTEM_ERROR )
     */
    void store(String outputPath, String fileName, DicomMetaData metaData) throws CommonException;
}
