package com.neurophet.maga.dicom.internal.interfaces;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.dicom.internal.dto.DicomPixelData;

import java.awt.image.Raster;

/**
 * DICOM 픽셀 데이터 처리
 *
 * @author 서강희
 */
public interface DicomPixelProvider {
    /**
     * Raster 객체로 부터 DICOM 픽셀 데이터 추출
     *
     * @param raster Raster 객체
     * @return 추출된 DICOM 픽셀 데이터
     * @throws CommonException DICOM 픽셀 이미지 추출 실패 ( SYSTEM_ERROR )
     */
    DicomPixelData extractPixelData(Raster raster) throws CommonException;
}
