package com.neurophet.maga.dicom.internal;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.dicom.internal.dto.DicomPixelData;
import com.neurophet.maga.dicom.internal.interfaces.DicomPixelProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.DataBufferShort;
import java.awt.image.DataBufferUShort;
import java.awt.image.Raster;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;


@Slf4j
@Service
@RequiredArgsConstructor
public class DicomPixelService implements DicomPixelProvider {
    @Override
    public DicomPixelData extractPixelData(final Raster raster) throws CommonException {
        final DataBuffer buffer = raster.getDataBuffer();

        // 1. 읽어온 DataBuffer 가 8bits 인 경우
        if (buffer instanceof DataBufferByte dataBufferByte) {
            return new DicomPixelData(dataBufferByte.getData().clone(), 8);
        }

        // 2. 읽어온 DataBuffer 가 16bits 인 경우 #1
        if (buffer instanceof DataBufferUShort dataBufferUShort) {
            short[] shortData = dataBufferUShort.getData();
            return new DicomPixelData(convertToBytes(shortData), 16);
        }

        // 3. 읽어온 DataBuffer 가 16bits 인 경우 #2
        if (buffer instanceof DataBufferShort dataBufferShort) {
            short[] shortData = dataBufferShort.getData();
            return new DicomPixelData(convertToBytes(shortData), 16);
        }

        throw new CommonException(CommonResultCode.SYSTEM_ERROR, "unsupported type: " + buffer.getClass().getName());
    }

    private byte[] convertToBytes(short[] shortData) {
        byte[] pixelData = new byte[shortData.length * 2];
        ByteBuffer.wrap(pixelData)
                  .order(ByteOrder.LITTLE_ENDIAN)
                  .asShortBuffer()
                  .put(shortData);
        return pixelData;
    }
}
