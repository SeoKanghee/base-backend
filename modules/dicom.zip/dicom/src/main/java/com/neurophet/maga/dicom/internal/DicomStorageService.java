package com.neurophet.maga.dicom.internal;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.dicom.internal.dto.DicomMetaData;
import com.neurophet.maga.dicom.internal.interfaces.DicomStorageProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.dcm4che3.io.DicomOutputStream;
import org.springframework.stereotype.Service;

import java.io.File;

@Slf4j
@Service
@RequiredArgsConstructor
public class DicomStorageService implements DicomStorageProvider {
    @Override
    public void store(
            final String outputPath, final String fileName, final DicomMetaData metaData
    ) throws CommonException {
        File outFile = new File(outputPath, fileName);
        try (DicomOutputStream dos = new DicomOutputStream(outFile)) {
            dos.writeDataset(metaData.fileMetaInfo(), metaData.dataMetaSet());
            log.debug("file stored successfully - {}", outFile.getName());
        } catch (Exception e) {
            // 예상 exception : IOException, IllegalArgumentException ( 필수 attrs 누락 ), NullPointerException
            log.error("exception occurs, cannot store dicom file - type : {}, message : {}",
                      e.getClass().getSimpleName(), e.getMessage());
            throw new CommonException(CommonResultCode.SYSTEM_ERROR, "cannot store dicom file - " + fileName);
        }
    }
}
