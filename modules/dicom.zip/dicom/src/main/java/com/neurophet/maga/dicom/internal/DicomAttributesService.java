package com.neurophet.maga.dicom.internal;

import com.neurophet.maga.dicom.internal.interfaces.DicomAttributesProvider;
import com.neurophet.maga.dicom.internal.utils.DicomUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.UID;
import org.dcm4che3.data.VR;
import org.jspecify.annotations.NonNull;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class DicomAttributesService implements DicomAttributesProvider {

    private static final Map<String, String> ENHANCED_TO_LEGACY_SOP_CLASS_UID = Map.of(
            UID.EnhancedCTImageStorage, UID.CTImageStorage,
            UID.EnhancedMRImageStorage, UID.MRImageStorage,
            UID.EnhancedMRColorImageStorage, UID.MRImageStorage,
            UID.EnhancedPETImageStorage, UID.PositronEmissionTomographyImageStorage,
            UID.EnhancedUSVolumeStorage, UID.UltrasoundImageStorage
    );

    @Override
    public Attributes prepareCommonSingleMetaDataSet(final Attributes orgMultiMetaDataSet) {
        final Attributes baseMetaDataSet = new Attributes(orgMultiMetaDataSet);

        // 1. Enhanced SOP Class UID를 Legacy로 변환
        convertSOPClassUID(baseMetaDataSet);

        // 2. Shared Functional Groups에서 공통 정보 추출해서 일반 태그로 변경
        promoteSharedFunctionalGroups(baseMetaDataSet);

        // 3. Enhanced 전용 태그 중 Shared 관련 제거
        removeSharedSequences(baseMetaDataSet);

        return baseMetaDataSet;
    }

    @Override
    public Attributes dispatchSingleMetaDataSetPerFrame(Attributes orgMultiMetaDataSet, int frameIndex) {
        final Attributes frameMetaDataSet = new Attributes(orgMultiMetaDataSet);

        // 프레임별 단순 처리
        updateSingleMetaDataSetFrame(frameMetaDataSet, frameIndex);

        // Per-Frame Functional Groups Sequence에서 Frame 별 정보 추출해서 일반 태그로 변경
        promotePerFrameFunctionalGroups(frameMetaDataSet, frameIndex);

        // 처리가 끝났으므로 Per-Frame Functional Groups Sequence 제거
        frameMetaDataSet.remove(Tag.PerFrameFunctionalGroupsSequence);

        return frameMetaDataSet;
    }

    /**
     * Enhanced SOP Class UID를 Legacy SOP Class UID로 변환
     *
     * @param attributes DICOM Attributes
     */
    void convertSOPClassUID(final Attributes attributes) {
        final String sopClassUID = attributes.getString(Tag.SOPClassUID);
        if (sopClassUID != null && ENHANCED_TO_LEGACY_SOP_CLASS_UID.containsKey(sopClassUID)) {
            // Enhanced SOP Class UID를 Legacy로 변환 -> 매칭되는 값이 없으면 원본 그대로 사용
            final String legacySOPClassUID = ENHANCED_TO_LEGACY_SOP_CLASS_UID.getOrDefault(sopClassUID, sopClassUID);
            attributes.setString(Tag.SOPClassUID, VR.UI, legacySOPClassUID);
            log.debug("converted SOP Class UID: {} -> {}", sopClassUID, legacySOPClassUID);
        }
    }

    /**
     * Shared Functional Groups Sequence에서 공통 정보를 추출하여 일반 태그로 변환
     *
     * @param attributes DICOM Attributes
     */
    void promoteSharedFunctionalGroups(@NonNull final Attributes attributes) {
        // SharedFunctionalGroupsSequence 에서 첫번째 item 추출 ( spec 상 1개만 존재 ) : (5200, 9229) > (FFFE, E000)
        final Attributes sharedItem
                = DicomUtil.extractAttrFromSequence(attributes, Tag.SharedFunctionalGroupsSequence, 0);
        if (sharedItem == null) {
            log.error("cannot find Shared Functional Groups Sequence");
            return;
        }

        promotePlaneOrientation(attributes, sharedItem);
        promotePixelMeasures(attributes, sharedItem);
    }

    /**
     * Plane Orientation Sequence 의 주요 태그를 최상위로 이동
     * <p>
     * Plane Orientation Sequence (0020, 9116) -> Image Orientation Patient (0020, 0037)
     *
     * @param attributes DICOM Attributes
     * @param sharedItem SharedFunctionalGroupsSequence 에서 첫번째 item
     */
    private void promotePlaneOrientation(@NonNull final Attributes attributes, @NonNull final Attributes sharedItem) {
        final Attributes planeOrientation
                = DicomUtil.extractAttrFromSequence(sharedItem, Tag.PlaneOrientationSequence, 0);
        DicomUtil.moveDoubleTag(attributes, planeOrientation, Tag.ImageOrientationPatient, 6);
    }

    /**
     * Pixel Measures Sequence 의 주요 태그를 최상위로 이동
     * <p>
     * Pixel Measures Sequence (0028, 9110) -> Pixel Spacing (0028, 0030)<br>
     * Pixel Measures Sequence (0028, 9110) -> Slice Thickness (0018, 0050)<br>
     * Pixel Measures Sequence (0028, 9110) -> Spacing Between Slices (0018, 0088)
     *
     * @param attributes DICOM Attributes
     * @param sharedItem SharedFunctionalGroupsSequence 에서 첫번째 item
     */
    private void promotePixelMeasures(@NonNull final Attributes attributes, @NonNull final Attributes sharedItem) {
        final Attributes pixelMeasures
                = DicomUtil.extractAttrFromSequence(sharedItem, Tag.PixelMeasuresSequence, 0);
        if (pixelMeasures != null) {
            DicomUtil.moveDoubleTag(attributes, pixelMeasures, Tag.PixelSpacing, 2);
            DicomUtil.moveDoubleTag(attributes, pixelMeasures, Tag.SliceThickness, 1);
            DicomUtil.moveDoubleTag(attributes, pixelMeasures, Tag.SpacingBetweenSlices, 1);
        }
    }

    /**
     * Single Frame 파일에서 필요없는 태그 제거
     *
     * @param attributes DICOM Attributes
     */
    void removeSharedSequences(final Attributes attributes) {
        attributes.remove(Tag.SharedFunctionalGroupsSequence);
        attributes.remove(Tag.DimensionOrganizationSequence);
        attributes.remove(Tag.DimensionIndexSequence);
    }

    /**
     * 프레임별 DICOM 태그 정보 수정
     *
     * @param attributes DICOM Attributes
     * @param frameIndex 프레임 인덱스 값
     */
    void updateSingleMetaDataSetFrame(@NonNull final Attributes attributes, final int frameIndex) {
        // (0028,0008) 개별 프레임이므로 number of frames 를 명시적으로 1로 설정
        attributes.setInt(Tag.NumberOfFrames, VR.IS, 1);

        // (0008,0018) SOP Instance UID 할당
        String originalUID = attributes.getString(Tag.SOPInstanceUID);
        attributes.setString(Tag.SOPInstanceUID, VR.UI, originalUID + "." + (frameIndex));

        // (0020,0013) 시리즈내 순서 정의
        attributes.setInt(Tag.InstanceNumber, VR.IS, frameIndex);
    }

    /**
     * Per-Frame Functional Groups Sequence에서 공통 정보를 추출하여 일반 태그로 변환
     *
     * @param attributes DICOM Attributes
     */
    void promotePerFrameFunctionalGroups(@NonNull final Attributes attributes, final int frameIndex) {
        // PerFrameFunctionalGroupsSequence 에서 frame 별 item 추출
        final int arrayIndex = frameIndex - 1;
        final Attributes perFrameItem
                = DicomUtil.extractAttrFromSequence(attributes, Tag.PerFrameFunctionalGroupsSequence, arrayIndex);
        if (perFrameItem == null) {
            log.error("cannot find Per-Frame Functional Groups Sequence");
            return;
        }

        promotePlanePosition(attributes, perFrameItem);
        promoteFrameContent(attributes, perFrameItem);
    }

    /**
     * Plane Position Sequence 의 주요 태그를 최상위로 이동
     * <p>
     * Plane Position Sequence (0020, 9113) -> Image Position Patient (0020, 0032)
     *
     * @param attributes   DICOM Attributes
     * @param perFrameItem PerFrameFunctionalGroupsSequence 에서 첫번째 item
     */
    private void promotePlanePosition(@NonNull final Attributes attributes, @NonNull final Attributes perFrameItem) {
        final Attributes planePosition
                = DicomUtil.extractAttrFromSequence(perFrameItem, Tag.PlanePositionSequence, 0);
        if (planePosition != null) {
            DicomUtil.moveDoubleTag(attributes, planePosition, Tag.ImagePositionPatient, 3);
        }
    }

    /**
     * Frame Content Sequence 의 주요 태그를 최상위로 이동
     *
     * @param attributes   DICOM Attributes
     * @param perFrameItem PerFrameFunctionalGroupsSequence 에서 첫번째 item
     */
    private void promoteFrameContent(@NonNull final Attributes attributes, @NonNull final Attributes perFrameItem) {
        final Attributes frameContent
                = DicomUtil.extractAttrFromSequence(perFrameItem, Tag.FrameContentSequence, 0);
        if (frameContent != null) {
            // TODO: 이거 사실 date time 이라 어떻게 처리할지 다시한번 확인
            DicomUtil.moveStringTag(attributes, frameContent, Tag.FrameAcquisitionDateTime);
        }
    }
}
