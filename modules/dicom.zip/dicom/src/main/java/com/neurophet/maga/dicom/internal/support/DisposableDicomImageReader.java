package com.neurophet.maga.dicom.internal.support;

import com.neurophet.maga.common.JacocoGenerated;
import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.dcm4che3.imageio.plugins.dcm.DicomImageReaderSpi;

import javax.imageio.ImageReader;

/**
 * DICOM Image Reader ( AutoCloseable )
 * <p>메모리 누수를 방지하기 위해 dispose 처리를 자동으로 하는 wrapper 클래스
 *
 * @author 서강희
 */
@Slf4j
@Getter
@JacocoGenerated    // JaCoCo 코드 커버리지 제외
public class DisposableDicomImageReader implements AutoCloseable {
    private final ImageReader reader;

    private DisposableDicomImageReader(ImageReader reader) {
        this.reader = reader;
    }

    public static DisposableDicomImageReader create() throws CommonException {
        try {
            DicomImageReaderSpi spi = new DicomImageReaderSpi();
            ImageReader reader = spi.createReaderInstance();
            if (reader == null) {
                throw new CommonException(CommonResultCode.SYSTEM_ERROR,
                                          "failed to create DICOM ImageReader");
            }
            return new DisposableDicomImageReader(reader);
        } catch (Exception e) {
            throw new CommonException(CommonResultCode.SYSTEM_ERROR,
                                      "cannot create DICOM ImageReader: " + e.getMessage());
        }
    }

    @Override
    public void close() {
        try {
            this.reader.dispose();
        } catch (Exception e) {
            // 예상 exception : NullPointerException
            log.error("cannot dispose ImageReader - {}", e.getMessage());
        }
    }
}
