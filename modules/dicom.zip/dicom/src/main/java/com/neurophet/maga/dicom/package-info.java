/**
 * DICOM module (Core Module)
 * <p>
 * DICOM 파일 관련 비즈니스 로직을 제공합니다.
 *
 * @author 서강희
 */
@org.springframework.modulith.ApplicationModule(
        displayName = "DICOM Module",
        allowedDependencies = {
                "common", "common::exceptions", "common::responses", "common::interfaces", "common::utils"
        }
)
package com.neurophet.maga.dicom;