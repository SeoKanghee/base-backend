package com.neurophet.maga.dicom;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.common.utils.FileUtil;
import com.neurophet.maga.common.utils.ValueGenerator;
import com.neurophet.maga.dicom.internal.dto.DicomMetaData;
import com.neurophet.maga.dicom.internal.dto.DicomPixelData;
import com.neurophet.maga.dicom.internal.interfaces.DicomAttributesProvider;
import com.neurophet.maga.dicom.internal.interfaces.DicomPixelProvider;
import com.neurophet.maga.dicom.internal.interfaces.DicomStorageProvider;
import com.neurophet.maga.dicom.internal.support.DisposableDicomImageReader;
import com.neurophet.maga.dicom.internal.utils.DicomUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.UID;
import org.dcm4che3.data.VR;
import org.jspecify.annotations.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.Raster;
import java.io.File;

/**
 * dicom frame splitter service
 *
 * @author 서강희
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class DicomFrameSplitterService {

    private final DicomAttributesProvider dicomAttributesProvider;
    private final DicomPixelProvider dicomPixelProvider;
    private final DicomStorageProvider dicomStorageProvider;

    /**
     * 멀티 프레임 DICOM 파일을 싱글 프레임으로 변환
     *
     * @param inputFile     DICOM 파일
     * @param strOutputPath 변환된 파일이 저장될 위치
     * @throws CommonException DICOM 파일을 읽을 수 없는 경우 ( INVALID_FILE )
     * @throws CommonException outputPath 가 확인되지 않는 경우 ( INVALID_PATH )
     */
    public void process(@NonNull final File inputFile, final String strOutputPath) throws CommonException {
        // 1. meta data 추출 및 유효성 확인 ( number of frames 정보가 없으면 exception )
        final DicomMetaData metaData = DicomUtil.getAttributes(inputFile);
        final int numberOfFrames = getNumberOfFrames(metaData.dataMetaSet());
        log.debug("number of frames : {}", numberOfFrames);

        // 2. 싱글 프레임 DICOM 파일이 저장될 경로 생성
        FileUtil.createDirectory(strOutputPath);

        // 3. 싱글 프레임 DICOM 파일 생성
        makeSingleFrameDicom(inputFile, strOutputPath, metaData);
    }

    /**
     * multi frame DICOM 파일이면 frame 개수를 반환
     *
     * @param attributes DICOM tag 정보 ( <code>org.dcm4che3.data.Attributes</code> )
     * @return frame 개수
     * @throws CommonException multi frame 이 아닌 경우 ( IGNORED_ERROR )
     * @throws CommonException DICOM 파일을 읽을 수 없는 경우 ( INVALID_FILE )
     */
    int getNumberOfFrames(final Attributes attributes) throws CommonException {
        try {
            int found = attributes.getInt(Tag.NumberOfFrames, -1);
            if (found < 2) {
                // multi frame DICOM 이 아닌 경우 ( tag 가 없거나 값이 1 인 경우 )
                throw new CommonException(CommonResultCode.IGNORED_ERROR,
                                          "number of frames tag (0028,0008) is invalid -> " + found);
            }
            return found;
        } catch (CommonException e) {
            throw e;
        } catch (Exception e) {
            // 예상 exception : NullPointerException
            throw new CommonException(CommonResultCode.INVALID_FILE, "cannot read dicom tag from attributes");
        }
    }

    /**
     * Single Frame DICOM 파일 생성 처리
     *
     * @param inputFile 원본 DICOM 파일
     * @param strOutputPath single frame DICOM 파일이 저장될 경로
     * @param orgMetaData 원본 DICOM 파일에서 추출한 meta data 정보
     * @throws CommonException DICOM 파일 저장 오류
     */
    void makeSingleFrameDicom(
            @NonNull final File inputFile, @NonNull final String strOutputPath, final DicomMetaData orgMetaData
    ) throws CommonException {
        try (
                DisposableDicomImageReader wrapper = DisposableDicomImageReader.create();
                ImageInputStream iis = ImageIO.createImageInputStream(inputFile)
        ) {
            // 1. ImageReader 와 ImageInputStream 으로 Image Data 추출 준비
            final ImageReader reader = wrapper.getReader();
            reader.setInput(iis);

            // 2. 실제 프레임 개수 확인 ( for loop )
            final int frameCount = reader.getNumImages(true);
            log.debug("frame count from image reader : {}", frameCount);

            // 3. 모든 프레임에 공통으로 적용될 Enhanced DICOM 메타데이터 사전 처리
            final Attributes baseMetaDataSet
                    = dicomAttributesProvider.prepareCommonSingleMetaDataSet(orgMetaData.dataMetaSet());

            // 4. 프레임 별로 이미지를 처리할 때 사용할 원본 이미지 정보
            final var defParam = reader.getDefaultReadParam();

            for (int i = 0; i < frameCount; i++) {
                // 5. Raster 객체에서 픽셀 데이터 추출
                final Raster raster = reader.readRaster(i, defParam);
                final DicomPixelData dicomPixelData = dicomPixelProvider.extractPixelData(raster);

                // 6. 새 프레임용 attributes 생성 및 메타데이터 동기화
                final int frameIndex = i + 1;
                final DicomMetaData frameMetaData
                        = dispatchFrameDicomMetaData(baseMetaDataSet, dicomPixelData, frameIndex);

                // 7. 개별 프레임 DICOM 파일 저장
                final String fileName = generateSplitFileName(inputFile, frameIndex);
                dicomStorageProvider.store(strOutputPath, fileName, frameMetaData);
            }
        } catch (CommonException e) {
            throw e;    // CommonException 은 내용 그대로 상위로 전달
        } catch (IIOException e) {
            // readRaster 에서 이미지 압축 해제가 실패일 경우 IIOException 발생 : INVALID_FILE 처리
            final String transferSyntaxInfo = getTransferSyntaxInfo(orgMetaData.fileMetaInfo());
            log.error("failed to decompress DICOM image by unsupported Transfer Syntax : {}", transferSyntaxInfo);
            throw new CommonException(CommonResultCode.INVALID_FILE, ValueGenerator.getExtraMessageBy(e));
        } catch (Exception e) {
            // 그외의 unchecked exception : FILE_SYSTEM_ERROR 처리
            log.error("exception occurs, cannot make single frame dicom file - type : {}, message : {}",
                      e.getClass().getSimpleName(), e.getMessage());
            throw new CommonException(CommonResultCode.FILE_SYSTEM_ERROR, ValueGenerator.getExtraMessageBy(e));
        }
    }

    DicomMetaData dispatchFrameDicomMetaData(
            final Attributes baseMetaDataSet, final DicomPixelData dicomPixelData, final int frameIndex
    ) {
        // 프레임 별 DICOM tag 및 픽셀 데이터 처리
        final Attributes frameMetaDataSet
                = dispatchFrameMetaDataSet(baseMetaDataSet, dicomPixelData, frameIndex);

        // 원본 정보와 상관 없이 Explicit VR Little Endian 처리
        final Attributes frameFileMetaInfo = frameMetaDataSet.createFileMetaInformation(UID.ExplicitVRLittleEndian);

        return new DicomMetaData(frameFileMetaInfo, frameMetaDataSet);
    }

    Attributes dispatchFrameMetaDataSet(
            final Attributes baseMetaDataSet, final DicomPixelData dicomPixelData, final int frameIndex
    ) {
        // 1. 프레임별 DICOM tag 및 픽셀 데이터 처리 -> 공통 정보가 적용된 base를 복사하여 사용
        Attributes frameMetaDataSet
                = dicomAttributesProvider.dispatchSingleMetaDataSetPerFrame(baseMetaDataSet, frameIndex);

        // 2. (7FE0,0010) 픽셀 데이터 주입 -> 16비트면 OW, 8비트면 OB
        final int bpp = dicomPixelData.bpp();
        if (bpp == 16) {
            frameMetaDataSet.setBytes(Tag.PixelData, VR.OW, dicomPixelData.pixelData());
        } else {
            frameMetaDataSet.setBytes(Tag.PixelData, VR.OB, dicomPixelData.pixelData());
        }

        return frameMetaDataSet;
    }

    String generateSplitFileName(final File inputFile, final int index) {
        final String baseFileName = StringUtils.stripFilenameExtension(inputFile.getName());
        final String postfix = String.format("%04d", index);    // 0001, 0002, ... , 0123, ..., 9999, 10000
        return baseFileName + "_" + postfix + ".dcm";
    }

    String getTransferSyntaxInfo(final Attributes fileMetaInfo) {
        final String transferSyntaxUID = fileMetaInfo.getString(Tag.TransferSyntaxUID);
        return DicomUtil.getNameByUid(transferSyntaxUID);
    }
}
