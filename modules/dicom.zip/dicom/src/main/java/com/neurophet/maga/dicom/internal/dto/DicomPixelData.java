package com.neurophet.maga.dicom.internal.dto;

import com.neurophet.maga.common.JacocoGenerated;
import org.jspecify.annotations.NonNull;

import java.util.Arrays;

/**
 * DICOM 이미지의 Pixel 데이터 정보를 담는 DTO
 *
 * @param pixelData 픽셀 데이터
 * @param bpp       Bits Per Pixel
 * @author 서강희
 */
@JacocoGenerated
public record DicomPixelData(
        byte[] pixelData,
        int bpp
) {
    // pixelData 로 인해 발생한 정적 분석 이슈를 해결하기 위한 기본 method Override
    // - java:S6218 Equals method should be overridden in records containing array fields

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DicomPixelData that = (DicomPixelData) o;
        return bpp == that.bpp && Arrays.equals(pixelData, that.pixelData);
    }

    @Override
    public int hashCode() {
        int result = Arrays.hashCode(pixelData);
        result = 31 * result + Integer.hashCode(bpp);
        return result;
    }

    @Override
    public @NonNull String toString() {
        return "DicomPixelData[" +
                "pixelData=" + Arrays.toString(pixelData) +
                ", bpp=" + bpp +
                ']';
    }
}
