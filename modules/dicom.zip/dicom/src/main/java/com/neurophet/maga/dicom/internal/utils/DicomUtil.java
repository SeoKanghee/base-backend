package com.neurophet.maga.dicom.internal.utils;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.dicom.internal.dto.DicomMetaData;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Sequence;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.UID;
import org.dcm4che3.data.VR;
import org.dcm4che3.io.DicomInputStream;
import org.dcm4che3.util.TagUtils;
import org.jspecify.annotations.NonNull;

import java.io.File;

/**
 * DicomUtil
 *
 * @author 서강희
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DicomUtil {
    /**
     * 표준 DICOM tag 정보를 통해 값을 반환 ( String )
     *
     * @param inputFile DICOM 파일
     * @param tag       <code>org.dcm4che3.data.Tag</code> 에서 확인 가능한 정보
     * @return 찾은 value
     * @throws CommonException input stream 으로 부터 attributes 를 읽어오지 못할 경우 ( IOException )
     * @throws CommonException attributes 가 null 인 경우 ( NullPointerException )
     */
    public static String readDicomTagToStr(
            @NonNull final File inputFile, final int tag
    ) throws CommonException {
        try (DicomInputStream inputStream = new DicomInputStream(inputFile)) {
            final Attributes attributes = inputStream.readDataset(Tag.PixelData);
            return attributes.getString(tag);
        } catch (Exception e) {
            // 예상 exception : IOException, NullPointerException
            throw new CommonException(CommonResultCode.INVALID_FILE, "cannot read tag to string from DICOM file");
        }
    }

    /**
     * 표준 DICOM tag 정보를 통해 값을 반환 ( int )
     *
     * @param inputFile DICOM 파일
     * @param tag       <code>org.dcm4che3.data.Tag</code> 에서 확인 가능한 정보
     * @param defValue  찾은 value 가 int 가 아닌 경우 반환할 default 값
     * @return 찾은 value
     * @throws CommonException input stream 으로 부터 attributes 를 읽어오지 못할 경우 ( IOException )
     * @throws CommonException attributes 가 null 인 경우 ( NullPointerException )
     */
    public static int readDicomTagToInt(
            @NonNull final File inputFile, final int tag, final int defValue
    ) throws CommonException {
        try (DicomInputStream inputStream = new DicomInputStream(inputFile)) {
            final Attributes attributes = inputStream.readDataset(Tag.PixelData);
            return attributes.getInt(tag, defValue);
        } catch (Exception e) {
            // 예상 exception : IOException, NullPointerException
            throw new CommonException(CommonResultCode.INVALID_FILE, "cannot read tag to int from DICOM file");
        }
    }

    /**
     * 표준 DICOM tag 가 아닌 경우를 찾기 위해 전체 tag 를 검색
     *
     * @param inputFile DICOM 파일
     * @param group     group
     * @param element   element
     * @return 찾은 value
     * @throws CommonException input stream 으로 부터 attributes 를 읽어오지 못할 경우 ( IOException )
     * @throws CommonException attributes 가 null 인 경우 ( NullPointerException )
     */
    public static String readPrivateTagValue(
            @NonNull final File inputFile, final int group, final int element
    ) throws CommonException {
        // group과 element를 하나의 정수형 Tag로 변환 (예: 0x0019, 0x1010 -> 0x00191010)
        final int targetTag = TagUtils.toTag(group, element);

        try (DicomInputStream inputStream = new DicomInputStream(inputFile)) {
            Attributes rootAttrs = inputStream.readDataset(Tag.PixelData);
            final String[] foundValue = { null };

            // full scan
            rootAttrs.accept(
                    (Attributes.Visitor) (attrs, visitedTag, vr, value) -> {
                        if (visitedTag == targetTag) {
                            foundValue[0] = attrs.getString(visitedTag);
                            return false;   // tag 를 발견하면 scan 중단
                        }
                        return true;
                    },
                    true    // recursive
            );

            return foundValue[0];
        } catch (Exception e) {
            // 예상 exception : IOException
            throw new CommonException(CommonResultCode.INVALID_FILE,
                                      "cannot read private tag from DICOM file -> (" + group + ", " + element + ")");
        }
    }

    /**
     * DICOM 파일의 tag 정보를 추출
     *
     * @param inputFile DICOM 파일
     * @return DICOM tag 정보
     * @throws CommonException input stream 으로 부터 attributes 를 읽어오지 못할 경우 ( IOException )
     */
    public static DicomMetaData getAttributes(@NonNull final File inputFile) throws CommonException {
        try (DicomInputStream inputStream = new DicomInputStream(inputFile)) {
            // attribute 를 개별 객체로 다루기 위해 파일 참조를 끊음
            inputStream.setBulkDataDescriptor(null);
            return new DicomMetaData(inputStream.readFileMetaInformation(), inputStream.readDataset(Tag.PixelData));
        } catch (Exception e) {
            // 예상 exception : IOException
            throw new CommonException(CommonResultCode.INVALID_FILE, "cannot read dicom file");
        }
    }

    /**
     * dcm4che 에서 정의한 UID 이름 반환
     *
     * @param uid UID
     * @return UID 이름
     */
    public static String getNameByUid(final String uid) {
        String interimUid = String.valueOf(uid);    // NullPointerException 방지
        String name = UID.nameOf(interimUid);   // name 으로 변환 -> 찾는 값이 없으면 "?" 반환
        return "?".equals(name) ? interimUid : name;    // "?" 인 경우 uid 그대로 반환 ( null 은 "null" 로 반환 )
    }

    /**
     * Sequence 의 n 번째 Item 을 반환
     *
     * @param parent      DICOM Attributes
     * @param sequenceTag Sequence Tag
     * @param index       index
     * @return Sequence 의 n 번째 Item
     */
    public static Attributes extractAttrFromSequence(
            final Attributes parent, final int sequenceTag, final int index
    ) {
        try {
            final Sequence sequence = parent.getSequence(sequenceTag);
            return sequence.get(index);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * VR 이 DS 인 태그를 추출해서 저장 ( source -> target )
     *
     * @param target            target DICOM Attributes
     * @param source            source DICOM Attributes
     * @param tag               Tag
     * @param valueMultiplicity Value Multiplicity ( 유효성 검증용 )
     */
    public static void moveDoubleTag(
            final Attributes target, final Attributes source, final int tag, final int valueMultiplicity
    ) {
        if (target != null && source != null) {
            final double[] doublesValue = source.getDoubles(tag);
            if (doublesValue != null) {
                if (doublesValue.length == 1) {
                    setByDoubleValue(target, doublesValue[0], tag);
                } else {
                    setByDoubleArrayValue(target, doublesValue, tag, valueMultiplicity);
                }
            }
        }
    }

    private static void setByDoubleValue(@NonNull final Attributes target, final double doubleValue, final int tag) {
        target.setDouble(tag, VR.DS, doubleValue);
    }

    private static void setByDoubleArrayValue(
            @NonNull final Attributes target, final double[] doublesValue, final int tag, final int valueMultiplicity
    ) {
        // 저장하려는 데이터의 value multiplicity 값이 일치하는지 확인
        if (doublesValue.length == valueMultiplicity) {
            target.setDouble(tag, VR.DS, doublesValue);
        }
    }

    public static void moveStringTag(final Attributes target, final Attributes source, final int tag) {
        if (target != null && source != null) {
            final String stringValue = source.getString(tag);
            if (stringValue != null && !stringValue.isEmpty()) {
                target.setString(tag, VR.DT, stringValue);
            }
        }
    }
}
