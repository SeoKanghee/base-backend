package com.neurophet.maga.dicom.internal.interfaces;

import org.dcm4che3.data.Attributes;

/**
 * DICOM Attributes 처리
 *
 * @author 서강희
 */
public interface DicomAttributesProvider {
    /**
     * 멀티 프레임에서 싱글 프레임으로 변환시 공통으로 적용될 기본 메타데이터 반환
     *
     * @param orgMultiMetaDataSet 원본 메타데이터 ( 멀티 프레임 )
     * @return 공통 정보가 적용된 메타데이터 ( 싱글 프레임 )
     */
    Attributes prepareCommonSingleMetaDataSet(Attributes orgMultiMetaDataSet);


    /**
     * 멀티 프레임에서 싱글 프레임으로 변환시 프레임 별 데이터 처리
     *
     * @param orgMultiMetaDataSet 원본 메타데이터 ( 멀티 프레임 )
     * @param frameIndex          프레임 인덱스 (1부터 시작)
     * @return 프레임 별로 처리된 메타데이터 ( 싱글 프레임 )
     */
    Attributes dispatchSingleMetaDataSetPerFrame(Attributes orgMultiMetaDataSet, int frameIndex);
}
