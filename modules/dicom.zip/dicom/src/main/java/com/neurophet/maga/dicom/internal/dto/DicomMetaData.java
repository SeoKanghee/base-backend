package com.neurophet.maga.dicom.internal.dto;

import org.dcm4che3.data.Attributes;

/**
 * DICOM tag 정보를 담는 DTO
 *
 * @param fileMetaInfo File Meta Information
 * @param dataMetaSet  DICOM Data Set
 * @author 서강희
 */
public record DicomMetaData(
        Attributes fileMetaInfo,
        Attributes dataMetaSet
) {
}
