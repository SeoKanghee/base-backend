package com.neurophet.maga.dicom;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.common.utils.FileUtil;
import com.neurophet.maga.dicom.internal.DicomAttributesService;
import com.neurophet.maga.dicom.internal.DicomPixelService;
import com.neurophet.maga.dicom.internal.DicomStorageService;
import com.neurophet.maga.dicom.internal.dto.DicomMetaData;
import com.neurophet.maga.dicom.internal.interfaces.DicomAttributesProvider;
import com.neurophet.maga.dicom.internal.interfaces.DicomPixelProvider;
import com.neurophet.maga.dicom.internal.interfaces.DicomStorageProvider;
import com.neurophet.maga.dicom.internal.support.DisposableDicomImageReader;
import com.neurophet.maga.dicom.internal.utils.DicomUtil;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.MockedStatic;
import org.springframework.util.StopWatch;

import javax.imageio.IIOException;
import javax.imageio.ImageReader;
import java.io.File;
import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("DicomFrameSplitterServiceTests")
class DicomFrameSplitterServiceTests {

    private static final String TEST_ROOT = "./temp";

    private DicomFrameSplitterService dicomFrameSplitterService;

    @BeforeEach
    void init() throws CommonException {
        FileUtil.createDirectory(TEST_ROOT);
    }

    @AfterEach
    void release() {
        FileUtil.removeDirectory(TEST_ROOT);
    }

    @Nested
    @DisplayName("processTests")
    class ProcessTests {
        private final String outputPath = TEST_ROOT + "/dicom/process";

        @BeforeEach
        void init() {
            DicomAttributesProvider dicomAttributesProvider = new DicomAttributesService();
            DicomPixelProvider dicomPixelProvider = new DicomPixelService();
            DicomStorageProvider dicomStorageProvider = new DicomStorageService();

            dicomFrameSplitterService = new DicomFrameSplitterService(
                    dicomAttributesProvider, dicomPixelProvider, dicomStorageProvider
            );
        }

        @ParameterizedTest
        @ValueSource(ints = { 8, 16 })
        @DisplayName("process test - 정상 처리")
        void processPassTest(final int bitDepth) {
            // given
            final String subPath = String.format("multi_frame_5_%sbits.dcm", bitDepth);
            final String inputPath = "./src/test/resources/dummy/multi-frame-dcm/" + subPath;
            final File inputFile = new File(inputPath);

            // when
            final StopWatch stopWatch = new StopWatch(subPath);
            stopWatch.start(String.valueOf(bitDepth));
            Assertions.assertDoesNotThrow(
                    () -> dicomFrameSplitterService.process(inputFile, outputPath)
            );
            stopWatch.stop();
            System.out.println(stopWatch.prettyPrint());
        }

        @Test
        @DisplayName("process test - 에러 #1 : single frame 이라 처리할 수 없는 경우")
        void processSingleFrameTest() {
            // given
            final String inputPath = "./src/test/resources/dummy/single-frame-dcm/single_frame_01.dcm";
            final File inputFile = new File(inputPath);

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> dicomFrameSplitterService.process(inputFile, outputPath)
            );

            // then
            Assertions.assertEquals(CommonResultCode.IGNORED_ERROR, result.getResultCode());
        }

        @Test
        @DisplayName("process test - 에러 #2 : 파일에 오류가 있는 경우 ( pixel data 크기가 잘못된 파일 )")
        void processInvalidFileTest() {
            // given
            final String inputPath = "./src/test/resources/dummy/multi-frame-dcm/invalid_multi_frame_5_8bits.dcm";
            final File inputFile = new File(inputPath);

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> dicomFrameSplitterService.process(inputFile, outputPath)
            );

            // then
            Assertions.assertEquals(CommonResultCode.FILE_SYSTEM_ERROR, result.getResultCode());
        }
    }

    @Nested
    @DisplayName("processWithMockTests")
    class ProcessWithMockTests {
        private final String outputPath = TEST_ROOT + "/dicom/process-with-mock";

        private DicomPixelProvider mockDicomPixelProvider;

        @BeforeEach
        void init() {
            DicomAttributesProvider mockDicomAttributesProvider = mock(DicomAttributesProvider.class);
            mockDicomPixelProvider = mock(DicomPixelProvider.class);
            DicomStorageProvider mockDicomStorageProvider = mock(DicomStorageProvider.class);

            dicomFrameSplitterService = new DicomFrameSplitterService(
                    mockDicomAttributesProvider, mockDicomPixelProvider, mockDicomStorageProvider
            );
        }

        @Test
        @DisplayName("process with mock test - 에러 #1 : DICOM tag 가 없는 경우")
        void processWithMockNoAttributeTest() {
            // DicomUtil mocking
            try (MockedStatic<DicomUtil> mockedDicomUtil = mockStatic(DicomUtil.class)) {
                // given - attributes 를 null 로 반환하도록 mocking
                mockedDicomUtil.when(
                        () -> DicomUtil.getAttributes(any())
                ).thenReturn(new DicomMetaData(null, null));

                // when
                final CommonException result = Assertions.assertThrows(
                        CommonException.class,
                        () -> dicomFrameSplitterService.process(new File("dummy"), outputPath)
                );

                // then - attributes 가 null 이라 exception 발생
                Assertions.assertEquals(CommonResultCode.INVALID_FILE, result.getResultCode());
            }
        }

        @Test
        @DisplayName("process with mock test - 에러 #2 : 파일에 오류가 있는 경우 ( pixel data 처리 중 오류 )")
        void processWithMockPixelErrorTest() throws CommonException {
            // given - exception mocking
            when(mockDicomPixelProvider.extractPixelData(any())).thenThrow(
                    new CommonException(CommonResultCode.SYSTEM_ERROR, "unsupported type: (mocking)")
            );

            // given
            final String inputPath = "./src/test/resources/dummy/multi-frame-dcm/multi_frame_5_16bits.dcm";
            final File inputFile = new File(inputPath);

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> dicomFrameSplitterService.process(inputFile, outputPath)
            );

            // then
            Assertions.assertEquals(CommonResultCode.SYSTEM_ERROR, result.getResultCode());
        }

        @Test
        @DisplayName("process with mock test - 에러 #3 : 파일에 오류가 있는 경우 ( 압축 오류 )")
        void processWithMockCompressionErrorTest() throws IOException {
            // DisposableDicomImageReader mocking
            try (MockedStatic<DisposableDicomImageReader> mockedWrapper = mockStatic(DisposableDicomImageReader.class)) {
                // given - mock ImageReader 생성
                ImageReader mockReader = mock(ImageReader.class);
                DisposableDicomImageReader mockDisposableReader = mock(DisposableDicomImageReader.class);

                // given - DisposableDicomImageReader.create()가 mock 객체를 반환하도록 설정
                mockedWrapper.when(DisposableDicomImageReader::create).thenReturn(mockDisposableReader);
                when(mockDisposableReader.getReader()).thenReturn(mockReader);

                // given - ImageReader의 동작 설정
                when(mockReader.getDefaultReadParam()).thenReturn(null);
                when(mockReader.getNumImages(true)).thenReturn(5);

                // given - readRaster 호출 시 IIOException 발생
                when(mockReader.readRaster(anyInt(), any())).thenThrow(
                        new IIOException("Unsupported compression: JPEG 2000")
                );

                final String inputPath = "./src/test/resources/dummy/multi-frame-dcm/multi_frame_5_16bits.dcm";
                final File inputFile = new File(inputPath);

                // when
                final CommonException result = Assertions.assertThrows(
                        CommonException.class,
                        () -> dicomFrameSplitterService.process(inputFile, outputPath)
                );

                // then
                Assertions.assertEquals(CommonResultCode.INVALID_FILE, result.getResultCode());
            }
        }
    }
}
