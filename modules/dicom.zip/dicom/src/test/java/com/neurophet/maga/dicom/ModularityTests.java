package com.neurophet.maga.dicom;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.modulith.core.ApplicationModules;
import org.springframework.modulith.docs.Documenter;

@DisplayName("ModularityTests - dicom")
class ModularityTests {
    private final ApplicationModules modules = ApplicationModules.of(DicomTestApplication.class);

    @Test
    @DisplayName("verify modular test - module dependency 가 잘 지켜지고 있는지 확인")
    void modularVerifyTest() {
        // domain base 의 package 구조가 무너지는 부분이 많아 Encapsulation 규칙 위반은 무시

        // given
        final String ignoredErrorMsg = "depends on non-exposed type";

        // when - non-exposed 에러 메시지는 제거
        var violations = modules.detectViolations();
        var filtered = violations.filter(v -> !v.getMessage().contains(ignoredErrorMsg));

        // then - non-exposed 에러 메시지 외에 다른 게 발견되는지 확인
        Assertions.assertDoesNotThrow(filtered::throwIfPresent);
    }

    @Test
    @DisplayName("create module doc test - module document 생성")
    void createModuleDocumentation() {
        // when, then
        Assertions.assertDoesNotThrow(
                () -> new Documenter(modules).writeDocumentation()
                                             .writeIndividualModulesAsPlantUml()
                                             .writeModulesAsPlantUml()
        );
        analyzeCommonDependencies();
    }

    private void analyzeCommonDependencies() {
        System.out.println("==================================================");
        modules.forEach(module -> {
            System.out.println("Module : " + module);
            var directDependencies = module.getDirectDependencies(modules);
            if (directDependencies.isEmpty()) {
                System.out.println("> dependencies : NONE");
            } else {
                System.out.println("> dependencies :");
                directDependencies.uniqueModules()
                                  .forEach(d -> System.out.println("  → " + d.getDisplayName()));
            }
            System.out.println("==================================================");
        });
    }
}
