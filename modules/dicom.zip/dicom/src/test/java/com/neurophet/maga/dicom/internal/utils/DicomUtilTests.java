package com.neurophet.maga.dicom.internal.utils;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.dicom.internal.dto.DicomMetaData;
import org.dcm4che3.data.Tag;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.File;

@DisplayName("DicomUtilTests")
class DicomUtilTests {
    @Nested
    @DisplayName("readDicomTagToStrTests")
    class ReadDicomTagToStrTests {
        @Test
        @DisplayName("readDicomTagToStr test - 정상적으로 읽는 경우")
        void readDicomTagToStrPassTest() {
            // given
            final String inputPath = "./src/test/resources/dummy/single-frame-dcm/single_frame_01.dcm";
            final File inputFile = new File(inputPath);

            // when
            final String result = Assertions.assertDoesNotThrow(
                    () -> DicomUtil.readDicomTagToStr(inputFile, Tag.PatientID)
            );

            // then
            Assertions.assertEquals("multi_frame_test", result);
        }

        @Test
        @DisplayName("readDicomTagToStr test - 파일이 없는 경우")
        void readDicomTagToStrFailNoFileTest() {
            // given
            final File inputFile = new File("not_exists_file");

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> DicomUtil.readDicomTagToStr(inputFile, Tag.PatientID)
            );

            // then
            Assertions.assertEquals(CommonResultCode.INVALID_FILE, result.getResultCode());
        }
    }

    @Nested
    @DisplayName("readDicomTagToIntTests")
    class ReadDicomTagToIntTests {
        @Test
        @DisplayName("readDicomTagToInt test - 정상적으로 읽는 경우")
        void readDicomTagToIntPassTest() {
            // given
            final String inputPath = "./src/test/resources/dummy/single-frame-dcm/single_frame_01.dcm";
            final File inputFile = new File(inputPath);

            // when
            final int result = Assertions.assertDoesNotThrow(
                    () -> DicomUtil.readDicomTagToInt(inputFile, Tag.NumberOfFrames, -1)
            );

            // then
            Assertions.assertEquals(1, result);
        }

        @Test
        @DisplayName("readDicomTagToInt test - int 로 변환할 수 없어서 default 값을 반환하는 경우")
        void readDicomTagToIntReturnDefaultTest() {
            // given
            final String inputPath = "./src/test/resources/dummy/single-frame-dcm/single_frame_01.dcm";
            final File inputFile = new File(inputPath);

            // when
            final int result = Assertions.assertDoesNotThrow(
                    () -> DicomUtil.readDicomTagToInt(inputFile, Tag.PatientID, -1)
            );

            // then
            Assertions.assertEquals(-1, result);
        }

        @Test
        @DisplayName("readDicomTagToInt test - 파일이 없는 경우")
        void readDicomTagToIntFailNoFileTest() {
            // given
            final File inputFile = new File("not_exists_file");

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> DicomUtil.readDicomTagToInt(inputFile, Tag.PatientID, -1)
            );

            // then
            Assertions.assertEquals(CommonResultCode.INVALID_FILE, result.getResultCode());
        }
    }

    @Nested
    @DisplayName("readPrivateTagValueTests")
    class ReadPrivateTagValueTests {
        @Test
        @DisplayName("readPrivateTagValue test - 정상적으로 읽는 경우")
        void readPrivateTagValuePassTest() {
            // given
            final String inputPath = "./src/test/resources/dummy/single-frame-dcm/single_frame_01.dcm";
            final File inputFile = new File(inputPath);

            // when
            final String result = Assertions.assertDoesNotThrow(
                    () -> DicomUtil.readPrivateTagValue(inputFile, 0x0010, 0x0020)
            );

            // then
            Assertions.assertEquals("multi_frame_test", result);
        }

        @Test
        @DisplayName("readPrivateTagValue test - 파일이 없는 경우")
        void readPrivateTagValueFailNoFileTest() {
            // given
            final File inputFile = new File("not_exists_file");

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> DicomUtil.readPrivateTagValue(inputFile, 0x0010, 0x0020)
            );

            // then
            Assertions.assertEquals(CommonResultCode.INVALID_FILE, result.getResultCode());
        }
    }

    @Nested
    @DisplayName("getAttributesTests")
    class GetAttributesTests {
        @Test
        @DisplayName("getAttributes test - 정상적으로 읽는 경우")
        void getAttributesPassTest() {
            // given
            final String inputPath = "./src/test/resources/dummy/single-frame-dcm/single_frame_01.dcm";
            final File inputFile = new File(inputPath);

            // when
            final DicomMetaData result = Assertions.assertDoesNotThrow(
                    () -> DicomUtil.getAttributes(inputFile)
            );

            // then
            Assertions.assertNotNull(result.fileMetaInfo());
            Assertions.assertNotNull(result.dataMetaSet());
        }

        @Test
        @DisplayName("getAttributes test - 파일이 없는 경우")
        void getAttributesFailNoFileTest() {
            // given
            final File inputFile = new File("not_exists_file");

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> DicomUtil.getAttributes(inputFile)
            );

            // then
            Assertions.assertEquals(CommonResultCode.INVALID_FILE, result.getResultCode());
        }
    }

    @Nested
    @DisplayName("getNameByUidTests")
    class GetNameByUidTests {
        @ParameterizedTest
        @CsvSource({
                // "?" 가 반환되는 경우 -> uid 값을 그대로 반환
                ", null",   // null
                "1.2.410.200144, 1.2.410.200144",   // product root uid

                // https://www.dicomlibrary.com/dicom/transfer-syntax/
                "1.2.840.10008.1.2.4.50, JPEG Baseline (Process 1)",
                "1.2.840.10008.1.2.4.51, JPEG Extended (Process 2 & 4)",

                // https://www.dicomlibrary.com/dicom/sop/
                "1.2.840.10008.1.1, Verification SOP Class",
                "1.2.840.10008.5.1.4.1.1.4, MR Image Storage",
                "1.2.840.10008.5.1.4.1.1.2, CT Image Storage",
        })
        @DisplayName("getNameByUid")
        void getNameByUidTest(final String uid, final String expectedResult) {
            // when
            final String result = Assertions.assertDoesNotThrow(
                    () -> DicomUtil.getNameByUid(uid)
            );

            // then
            Assertions.assertEquals(expectedResult, result);
        }
    }
}
