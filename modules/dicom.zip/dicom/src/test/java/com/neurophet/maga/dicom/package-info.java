// module 내부 검증을 위한 dependencies 제약 제거
@org.springframework.modulith.ApplicationModule(
        displayName = "Dicom Test Module"
)
package com.neurophet.maga.dicom;