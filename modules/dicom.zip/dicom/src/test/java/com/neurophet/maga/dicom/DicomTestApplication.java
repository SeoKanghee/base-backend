package com.neurophet.maga.dicom;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DicomTestApplication {
    // module 전환 후 main application 이 존재하지 않으므로 test 용 선언
}
