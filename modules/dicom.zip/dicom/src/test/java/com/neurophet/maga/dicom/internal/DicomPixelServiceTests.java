package com.neurophet.maga.dicom.internal;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.dicom.internal.dto.DicomPixelData;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.image.ComponentSampleModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferShort;
import java.awt.image.Raster;
import java.awt.image.SampleModel;

class DicomPixelServiceTests {

    private DicomPixelService dicomPixelService;

    @BeforeEach
    void init() {
        dicomPixelService = new DicomPixelService();
    }

    @Nested
    @DisplayName("extractPixelDataTests")
    class ExtractPixelDataTests {
        @Test
        @DisplayName("extractPixelData test - 데이터 정상 추출 ( 8bits )")
        void extractPixelDataPass8bitsTest() {
            // given
            final Raster raster = Raster.createInterleavedRaster(
                    DataBuffer.TYPE_BYTE, 10, 10, 1, null
            );

            // when
            final DicomPixelData result = Assertions.assertDoesNotThrow(
                    () -> dicomPixelService.extractPixelData(raster)
            );

            // then
            Assertions.assertEquals(8, result.bpp());
        }

        @Test
        @DisplayName("extractPixelData test - 데이터 정상 추출 ( 16bits unsigned )")
        void extractPixelDataPass16bitsUnsignedTest() {
            // given
            final Raster raster = Raster.createInterleavedRaster(
                    DataBuffer.TYPE_USHORT, 10, 10, 1, null
            );

            // when
            final DicomPixelData result = Assertions.assertDoesNotThrow(
                    () -> dicomPixelService.extractPixelData(raster)
            );

            // then
            Assertions.assertEquals(16, result.bpp());
        }

        @Test
        @DisplayName("extractPixelData test - 데이터 정상 추출 ( 16bits signed )")
        void extractPixelDataPass16bitsSignedTest() {
            // given
            short[] data = new short[10 * 10];
            DataBufferShort dataBuffer = new DataBufferShort(data, data.length);
            SampleModel sampleModel = new ComponentSampleModel(
                    DataBuffer.TYPE_SHORT, 10, 10, 1, 10, new int[]{ 0 }
            );
            final Raster raster = Raster.createWritableRaster(sampleModel, dataBuffer, new Point(0, 0));

            // when
            final DicomPixelData result = Assertions.assertDoesNotThrow(
                    () -> dicomPixelService.extractPixelData(raster)
            );

            // then
            Assertions.assertEquals(16, result.bpp());
        }

        @Test
        @DisplayName("extractPixelData test - 지원하지 않는 포맷")
        void extractPixelDataFailUnsupportedTest() {
            // given
            final Raster raster = Raster.createPackedRaster(
                    DataBuffer.TYPE_INT, 10, 10, new int[]{ 0xFF0000, 0xFF00, 0xFF }, null
            );

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> dicomPixelService.extractPixelData(raster)
            );

            // then
            Assertions.assertEquals(CommonResultCode.SYSTEM_ERROR, result.getResultCode());
        }
    }
}
