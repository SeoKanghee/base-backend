package com.neurophet.maga.dicom.internal;

import com.neurophet.maga.common.exception.CommonException;
import com.neurophet.maga.common.response.CommonResultCode;
import com.neurophet.maga.common.utils.FileUtil;
import com.neurophet.maga.dicom.internal.dto.DicomMetaData;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.UID;
import org.dcm4che3.data.VR;
import org.dcm4che3.util.UIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.Date;

@DisplayName("DicomStorageServiceTests")
class DicomStorageServiceTests {

    private static final String TEST_ROOT = "./temp";

    private DicomStorageService dicomStorageService;

    @BeforeEach
    void init() throws CommonException {
        FileUtil.createDirectory(TEST_ROOT);
        dicomStorageService = new DicomStorageService();
    }

    @AfterEach
    void release() {
        FileUtil.removeDirectory(TEST_ROOT);
    }

    @Nested
    @DisplayName("storeTests")
    class StoreTests {
        @Test
        @DisplayName("store test - 저장에 성공하는 경우")
        void storePassTest() throws CommonException {
            // given
            final String outputPath = Path.of(TEST_ROOT, "store").toString();
            FileUtil.createDirectory(outputPath);

            final Attributes dataMetaSet = getMandatoryDataMetaSet();
            final Attributes fileMetaInfo = dataMetaSet.createFileMetaInformation(UID.ExplicitVRLittleEndian);

            // when, then
            Assertions.assertDoesNotThrow(
                    () -> dicomStorageService.store(
                            outputPath, "valid_store_test.dcm",
                            new DicomMetaData(fileMetaInfo, dataMetaSet)
                    )
            );
        }

        private Attributes getMandatoryDataMetaSet() {
            Attributes attrs = new Attributes();

            attrs.setString(Tag.PatientName, VR.PN, "Mandatory^Kim");
            attrs.setString(Tag.PatientID, VR.LO, "store_test");
            attrs.setDate(Tag.StudyDate, VR.DA, new Date());
            attrs.setString(Tag.AccessionNumber, VR.SH, "ACC001");

            attrs.setString(Tag.SOPClassUID, VR.UI, UID.SecondaryCaptureImageStorage);
            attrs.setString(Tag.SOPInstanceUID, VR.UI, UIDUtils.createUID());
            attrs.setString(Tag.StudyInstanceUID, VR.UI, UIDUtils.createUID());
            attrs.setString(Tag.SeriesInstanceUID, VR.UI, UIDUtils.createUID());

            return attrs;
        }

        @Test
        @DisplayName("store test - Attribute 가 없어서 저장에 실패하는 경우 (NullPointerException)")
        void storeFailNoAttributesTest() throws CommonException {
            // given
            final String outputPath = Path.of(TEST_ROOT, "store").toString();
            FileUtil.createDirectory(outputPath);

            // when
            final CommonException result = Assertions.assertThrows(
                    CommonException.class,
                    () -> dicomStorageService.store(
                            outputPath, "invalid_store_test.dcm",
                            new DicomMetaData(null, null)
                    )
            );

            // then
            Assertions.assertEquals(CommonResultCode.SYSTEM_ERROR, result.getResultCode());
        }
    }
}
